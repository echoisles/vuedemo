$("input").focus(function(){
    $(this).next().animate({width:'100%'},1000)
});
$("input").blur(function(){
    $(this).next().animate({left:'100%'},1000,function () {
        $(this).css({width:'0%',left:"0%"})
    })
});